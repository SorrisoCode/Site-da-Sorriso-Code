<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css?v=999">
</head>

<body>

    <div class="logo">
        <img src="img/logo.png" alt="Logo da Sorriso Code" class="img-fluid logo-img">
    </div>

    <form action="dados.php?var=login" method="post" enctype="multipart/form-data">

        <label>Nome:</label>
        <input type="text" name="nome" maxlength="50" required>

        <label>Email:</label>
        <input type="email" name="email" maxlength="150" required>

        <label>Senha:</label>
        <div class="senha-box">
            <input type="password" id="password" name="senha" required>
        </div>

        <label>Data de Nascimento:</label>
        <input type="date" name="datanasc" id="dtnasc" min="1920-01-01" max="2025-12-31" required>

        <label>Nacionalidade:</label>
        <input type="text" name="nacionalidade" maxlength="50" required>

        <label>Endereço:</label>
        <input type="text" name="endereco" maxlength="50" required>

        <label>Foto:</label>
        <input type="file" accept="image/*" name="arq" id="foto">
        <br><br>
        <img id="preview" class="img-upload" style="display: none;">

        <div class="col-12">
            <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
            <label class="form-check-label" for="invalidCheck">
                Condordo com os termos e condições.
            </label>
            <div class="invalid-feedback">
                Você deve concordar com os termos antes de enviar o form.
            </div>
            </div>
        </div>

        <button type="submit">Logar na Sorriso Code</button>

    </form>
    <br><br>    
    <script>
        document.getElementById("foto").addEventListener("change", function(event) {
            const file = event.target.files[0];
            
            if (file) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    const img = document.getElementById("preview");
                    img.src = e.target.result;
                    img.style.display = "block";
                }

                reader.readAsDataURL(file);
            }
        });
    </script>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>