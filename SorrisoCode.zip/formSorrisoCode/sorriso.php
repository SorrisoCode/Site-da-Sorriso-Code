<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">  
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="topo" style="padding-top: 70px;">

<header>
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">

        <a href="#SorrisoCode" class="logo-header">
            <img src="img/cara.png">
            <img src="img/letras.png">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            <span class="menu-icon">&#9776;</span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="menu">

            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="#dados">Dados</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contato">Contato</a>
                </li>
            </ul>

            <a class="btn btn-login btn-salmon ms-2" href="index.php">Voltar ao login</a>

        </div>
    </div>
</nav>
</header>

<main class="container text-center mt-5 pt-5" id="SorrisoCode">
    <h1>Sorriso Code: Designs e Websites Responsivos!</h1>
    <p style="margin-top: 30px;">Eu, Beatriz Vasconcelos (ou Sorriso), crio websites, landing pages e designs personalizados que fortalecem a identidade da sua marca e conectam você ao seu público.</p>
    <p>Oferecer soluções criativas e estratégicas, unindo estética e funcionalidade para transformar suas ideias em resultado é o meu objetivo!</p>
    <div style="text-align: center; margin-top: 40px; margin-bottom: 20px;">
        <img src="img/marca.png" width="400" height="400" class="img-fluid mb-4" alt="colagem">
    </div>
    <p>O que transforma ideias em realidade não é sorte, é consistência, coragem e vontade de melhorar um pouco a cada dia. Então, desenvolvo projetos de websites com foco em performance, responsividade e experiência do usuário. Utilizo tecnologias modernas como HTML, CSS, PHP e Bootstrap para desenvolver páginas bem estruturadas, funcionais e visualmente profissionais.</p>
    <p>A motivação é transformar ideias em sites reais, combinando design limpo com código eficiente, garantindo que cada projeto seja rápido, acessível e adaptado a qualquer dispositivo.</p>
     <div style="text-align: center; margin-top: 40px; margin-bottom: 40px;">
        <img src="img/layout.jpg" width="300" height="300" class="img-fluid mb-4" alt="colagem">
    </div>
    <p>Minha arte é criada para dar vida a ideias e transformar emoções em design. Trabalho com frases motivacionais, cartões personalizados, cartão de mensagem, convites para festas e eventos especiais, além de artes para redes sociais, posts criativos, banners e capas.</p>

<p>Também desenvolvo logotipos, identidades visuais, flyers, panfletos, cartões de visita e materiais promocionais para marcas e pequenos negócios. Cada criação é feita com cuidado para transmitir personalidade, estilo e originalidade em cada detalhe.</p>
    <div class="galeria">
    <img src="img/margaridas.jpg" alt="colagem">
    <img src="img/moldura.png" alt="colagem">
</div>
<p>Meu processo de criação começa com a conversa com o cliente, onde busco entender suas ideias, objetivos e o estilo que deseja transmitir. Nessa etapa de interação, faço perguntas para coletar informações importantes, como o tipo de arte, cores preferidas, mensagem desejada e o contexto do projeto.</p>

<p>Com base nisso, transformo essas informações em um conceito visual, desenvolvendo uma proposta que una criatividade e propósito. Durante o processo, mantenho o cliente envolvido, ajustando detalhes e garantindo que o resultado final represente exatamente o que ele imaginou — ou até mais do que esperava.</p>
    <div style="text-align: center; margin-top: 40px; margin-bottom: 20px;">
        <img src="img/coracao.png" width="300" height="300" class="img-fluid mb-4" alt="colagem">
    </div>
    <p>A interação com o cliente é feita de forma simples, rápida e organizada, através de direct ou e-mail. Nesse primeiro contato, o cliente pode enviar sua ideia, referência ou necessidade, e eu faço as perguntas necessárias para entender melhor o projeto.</p>
    <p>A partir disso, mantemos uma comunicação clara durante todo o processo, enviando atualizações, ajustes e prévias quando necessário. O objetivo é garantir praticidade, confiança e um resultado final alinhado exatamente com o que o cliente deseja.</p>
     <div style="text-align: center; margin-top: 40px;">
        <img src="img/carta.png" width="500" height="500" class="img-fluid mb-4" alt="colagem">
    </div>
    <div style="text-align: center; margin-top: 20px; margin-bottom: 40px;">
    <a href="#topo" class="btn-rosa">Voltar ao início</a>
    </div>
</main>

<footer class="footer mt-auto">
    <div class="container">

        <div class="footer-content">
            
            <!-- ESQUERDA (logo) -->
            <div class="footer-logo">
                <img src="img/cara.png">
                <img src="img/letras.png">
            </div>

            <!-- DIREITA (infos) -->
            <div class="footer-info text-end">
                <h5 class="mb-1">Beatriz Andrade Vasconcelos</h5>
                <h5 class="mb-0" id="contato">biavasconcelosarmy@gmail.com</h5>
            </div>

        </div>

        <!-- PARTE DE BAIXO CENTRAL -->
        <div class="text-center mt-3">
            <small>© 2026 Sorriso Code</small>
        </div>

    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>