<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">  
    <link rel="stylesheet" href="css/style.css">
</head>

<body  class="pagina-dados">

<header>
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">

        <a href="#SorrisoCode" class="logo-header">
            <img src="img/cara.png">
            <img src="img/letras.png">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            <span class="menu-icon">&#9776;</span>
        </button>

       <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav ms-auto">
             <li class="nav-item">
            <a class="nav-link active" href="#dados">Dados</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="#contato">Contato</a>
            </li>
            </ul>

            <a class="btn btn-login btn-salmon ms-2" href="index.php">Voltar ao login</a>
        </div>
    </div>
</nav>
</header>

<main class="container"  id="SorrisoCode">
    <div class="dados-box">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $nome = $_POST["nome"];
            $endereco = $_POST["endereco"];
            $datanasc = $_POST["datanasc"];
            $email = $_POST["email"];
            $senha = $_POST["senha"];
            $nacionalidade = $_POST["nacionalidade"];
            $arq = $_FILES["arq"]["name"];
            $tmp = $_FILES["arq"]["tmp_name"];

            $caminho = "uploads/" . $arq;

            move_uploaded_file($tmp, $caminho);

            echo "<h2>DADOS DO FORM</h2>";

            echo "<div class='dados-linha'><span>Nome:</span> $nome</div>";
            echo "<div class='dados-linha'><span>E-mail:</span> $email</div>";
            echo "<div class='dados-linha'><span>Data de nascimento:</span> $datanasc</div>";
            echo "<div class='dados-linha'><span>Nacionalidade:</span> $nacionalidade</div>";
            echo "<div class='dados-linha'><span>Endereço:</span> $endereco</div>";
            echo "<div class='dados-linha'><span>Arquivo:</span> $arq</div>";

            echo "<div class='dados-img'>";
            echo "<img src='$caminho' class='img-upload'>";
            echo "</div>";
        }
        ?>
    </div>
    <a href="sorriso.php" class="btnDados">Entrar na Sorriso Code</a>
</main>

<footer class="footer mt-auto">
    <div class="container">

        <div class="footer-content">
            
            <!-- ESQUERDA (logo) -->
            <div class="footer-logo">
                <img src="img/cara.png">
                <img src="img/letras.png">
            </div>

            <!-- DIREITA (infos) -->
            <div class="footer-info text-end">
                <h5 class="mb-1">Beatriz Andrade Vasconcelos</h5>
                <h5 class="mb-0" id="contato">biavasconcelosarmy@gmail.com</h5>
            </div>

        </div>

        <!-- PARTE DE BAIXO CENTRAL -->
        <div class="text-center mt-3">
            <small>© 2026 Sorriso Code</small>
        </div>

    </div>
</footer>

<script>
    // Captura o botão pelo ID
    const btn = document.getElementById("btnSorriso");

    // Adiciona evento de clique
    btn.addEventListener("click", function() {
      window.location.href = "sorriso.php";
    });
  </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>